===================
Python Memory Tools
===================

This package provides not only a decorator, but a wrapper over two common k-v memory storages.