#!/usr/bin/env python

__author__ = 'Pablo Alejandro Costesich'
__version__ = '0.2.0'
__docformat__ = 'reStructuredText en'
